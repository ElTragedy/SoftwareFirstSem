//README
/*
 *
 * please move this later. I just made a skeleton before we make the structure
 * and design of where our code is going and why. We can move this when
 * we have a more intrecate set up to where it belongs. For now it is just
 * a skeleton to work on later.
 *
 * ALSO: Probably rename the file to HotelReservationCancel.java and 
 * have it extend hotel or something, not sure yet we will figure it out
 * another day probably.
 *
 */


//package com.example.hotelreservation;

import java.util.*;

public class ReservationCancel {
    ReservationCancel() {
        //constructor
    }
    public static void main(String[] args) {
        //main
    }

}
